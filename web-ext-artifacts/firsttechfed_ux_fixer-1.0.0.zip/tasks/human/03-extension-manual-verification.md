# Task: Extension Manual Verification
Priority: High
Estimated Time: 1-2 hours
Dependencies: Built extension, Firefox browser, access to firsttechfed.com
Status: Not Started

## Objective
Manually verify that the Firefox extension applies the dense, CLI-inspired UI and preserves all functionality on firsttechfed.com, especially the dashboard and transfer forms.

## Steps
1. [ ] Build the extension (`npm run build`)
2. [ ] Load the extension in Firefox via `about:debugging` > "Load Temporary Add-on" > select `manifest.json`
3. [ ] Log in to firsttechfed.com
4. [ ] Navigate to the dashboard page
5. [ ] Verify:
    - [ ] Dense layout is applied (minimal whitespace, compact UI)
    - [ ] Navigation is always visible (no hamburger/dropdown menus)
    - [ ] All dropdowns are replaced with radio buttons or inline options
    - [ ] Forms use CLI-inspired, text-based design
    - [ ] No hidden options or popups
    - [ ] All original functionality is preserved
6. [ ] Navigate to the transfer page and repeat the above checks
7. [ ] Test keyboard navigation and accessibility (tab order, focus indicators)
8. [ ] Check for console errors in Firefox Developer Tools
9. [ ] Note any issues, unexpected behaviors, or visual bugs

## Data Collection
- Location: tasks/human/validation/
- Format: Screenshots, notes, bug reports
- Validation: All checklist items above are met

## Success Criteria
- [ ] Extension loads and applies styles without errors
- [ ] Dense, CLI-inspired UI is visible on dashboard and transfer pages
- [ ] No dropdowns, hamburger menus, or hidden options remain
- [ ] All site functionality is preserved
- [ ] No critical console errors

## Notes
- Use Firefox Developer Edition for best results
- If issues are found, document with screenshots and steps to reproduce

## Progress Updates
### [Date] - [Duration]
- [ ] Step completed
- [ ] Issues encountered
- [ ] Next steps 